# pfc/main.py
# from pfc.shell.repl import start

# if __name__ == "__main__":
#     start()

# pfc/main.py
from pfc.shell.repl import start

def main():
    start()

if __name__ == "__main__":
    main()

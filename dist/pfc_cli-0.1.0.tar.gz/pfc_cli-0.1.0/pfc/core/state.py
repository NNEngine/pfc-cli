# pfc/core/state.py
class Session:
    def __init__(self):
        self.df = None
        self.file = None

session = Session()
